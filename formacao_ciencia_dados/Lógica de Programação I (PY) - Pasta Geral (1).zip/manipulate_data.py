import os 

import os 
import json

def load_json_file(folder_name, file_name):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, folder_name, file_name + '.json')
    if not os.path.exists(file_path):
        return None
    with open(file_path, 'r') as f:
        data = json.load(f)
        result = []
        for restaurant in data:
            nome_restaurante = restaurant['nome']
            lat = restaurant['localizacao'][0]
            lon = restaurant['localizacao'][1]
            n_pedidos = len(restaurant['pedidos'])
            result.append([nome_restaurante, [lat, lon], n_pedidos])
        return result

def save_json_file(folder_name, file_name, data):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, folder_name, file_name + '.json')
    data_json = [{'nome': nome, 'localizacao': localizacao, 'pedidos': []} for nome, localizacao, _ in data]
    with open(file_path, 'w') as f:
        json.dump(data_json, f, indent=4)